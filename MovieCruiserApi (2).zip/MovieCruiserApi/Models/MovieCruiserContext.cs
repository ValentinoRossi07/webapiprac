﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Web;

namespace MovieCruiserApi.Models
{
    public class MovieCruiserContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=.;Initial Catalog=MovieCruiser;Integrated Security=True;");
        }

        public DbSet<Favorites> Favorites { get; set; }

        public DbSet<MovieList> MovieList { get; set; }

        public DbSet<UserDetails> UserDetails { get; set; }
    }
}
